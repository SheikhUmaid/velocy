import 'package:flutter/material.dart';
import 'package:velocy_user_app/view/module/user/driver_arriver_screen/ui/widget/driver_arrival_scrren_widget.dart';

class DriverArrivelScreen extends StatelessWidget {
  const DriverArrivelScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DriverArrivalScrrenWidget();
  }
}
