import 'package:flutter/material.dart';
import 'package:velocy_user_app/view/module/user/driver_wating/ui/widget/driver_wating_page_widget.dart';

class DriverWatingPage extends StatelessWidget {
  const DriverWatingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const DriverWaitingPage();
  }
}
