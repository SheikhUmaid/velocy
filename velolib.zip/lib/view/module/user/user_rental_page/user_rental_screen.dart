import 'package:flutter/material.dart';

class UserRentalScreen extends StatelessWidget {
  const UserRentalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
