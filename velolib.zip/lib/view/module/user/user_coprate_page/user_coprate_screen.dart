import 'package:flutter/material.dart';

class UserCoprateScreen extends StatelessWidget {
  const UserCoprateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
