import 'package:flutter/material.dart';

class UserPoolScreen extends StatelessWidget {
  const UserPoolScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
