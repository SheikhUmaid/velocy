import 'package:flutter/material.dart';

class DriRecentRidesScreen extends StatelessWidget {
  const DriRecentRidesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
