import 'package:flutter/cupertino.dart';

class CancelledWidget extends StatelessWidget {
  const CancelledWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(child: Column(children: [

    ],));
  }
}
