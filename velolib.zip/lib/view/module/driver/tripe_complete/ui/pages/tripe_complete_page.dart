import 'package:flutter/material.dart';
import 'package:velocy_user_app/view/module/driver/tripe_complete/ui/widget/tripe_complete_widget.dart';

class TripeCompletePage extends StatelessWidget {
  const TripeCompletePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const TripeCompleteWidget();
  }
}
