import 'package:flutter/material.dart';
import 'package:velocy_user_app/utils/custom_appbar.dart';

class ReportSubmitPage extends StatelessWidget {
  const ReportSubmitPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: CustomAppBar(title: ""));
  }
}
