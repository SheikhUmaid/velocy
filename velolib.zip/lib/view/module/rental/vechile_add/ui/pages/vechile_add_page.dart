import 'package:flutter/material.dart';
import 'package:velocy_user_app/view/module/rental/vechile_add/ui/widget/vechile_add_page.dart';

class VechileAddPage extends StatelessWidget {
  const VechileAddPage({super.key});

  @override
  Widget build(BuildContext context) {
    return VechileAddPageWidget();
  }
}
