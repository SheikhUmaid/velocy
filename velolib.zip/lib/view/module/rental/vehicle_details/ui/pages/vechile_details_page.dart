import 'package:flutter/material.dart';
import 'package:velocy_user_app/view/module/rental/vehicle_details/ui/widget/vechile_details_widget.dart';

class VechileDetailsPage extends StatelessWidget {
  const VechileDetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const VechileDetailsWidget();
  }
}
