import 'package:flutter/material.dart';

class VechileCardWidget extends StatelessWidget {
  const VechileCardWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      
    );
  }
}