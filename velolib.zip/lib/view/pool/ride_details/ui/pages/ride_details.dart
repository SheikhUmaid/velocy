import 'package:flutter/material.dart';
import 'package:velocy_user_app/view/pool/ride_details/ui/widget/ride_details_widget.dart';

class RideDetailsPages extends StatelessWidget {
  const RideDetailsPages({super.key});

  @override
  Widget build(BuildContext context) {
    return const RideDetailsWidget();
  }
}
