
import 'package:get/get.dart';
import 'package:velocy_user_app/controller/register_controller/register_controller.dart';


init() async {

  Get.put(RegisterController());

}
