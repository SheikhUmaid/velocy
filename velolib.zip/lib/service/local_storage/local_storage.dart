import 'package:get/get.dart';

class LocalStorage {
  // static RxString id = "id".obs;

}